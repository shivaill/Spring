package org.techzoo.restful;
 
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
 
@Path("/greeting")
public class GreetingService {

	@GET
	@Path("/{name}")
	public Response sayGreeting(@PathParam("name") String msg) {
		String output = String.format("Greeting to %s from Jersey", msg);
		return Response.status(200).entity(output).build();
	}
}